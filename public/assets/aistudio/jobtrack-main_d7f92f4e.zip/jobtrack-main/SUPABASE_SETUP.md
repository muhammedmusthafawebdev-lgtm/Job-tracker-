# JobTrack Supabase setup

This repository targets Supabase project `obtzjxwkwkshlezwgvlg` at `https://obtzjxwkwkshlezwgvlg.supabase.co`. The migrations are stored locally and have not been applied by this task.

## Local environment

Copy `.env.example` to `.env.local` and set the publishable client key supplied by the authorized Supabase project:

```bash
VITE_SUPABASE_URL=https://obtzjxwkwkshlezwgvlg.supabase.co
VITE_SUPABASE_ANON_KEY=<Supabase publishable key>
VITE_SUPABASE_REDIRECT_URL=http://localhost:3000
```

Never place a service-role key in Vite environment variables or commit any `.env` file.

## Database migrations

Apply these files in order after verifying that the active Supabase project reference is exactly `obtzjxwkwkshlezwgvlg`:

1. `supabase/migrations/001_initial_schema.sql` creates `public.job_applications`, constraints, and indexes.
2. `supabase/migrations/002_rls_policies.sql` enables RLS and limits CRUD to `auth.uid() = user_id`.
3. `supabase/migrations/003_updated_at_trigger.sql` maintains `updated_at` on updates.

## Supabase Dashboard configuration

Configure Auth > URL Configuration with exact trusted URLs for the deployed application origin and local development origin. Set `VITE_SUPABASE_REDIRECT_URL` to the exact origin used by each deployment; do not use a wildcard. The email confirmation and password recovery redirects must return to the app origin so the client can process the Supabase session.

The frontend uses Supabase Auth session persistence, automatic refresh, recovery-link detection, and the `PASSWORD_RECOVERY` auth event. The dashboard remains protected by rendering it only when a valid Supabase session exists.
