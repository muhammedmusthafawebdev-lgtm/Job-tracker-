alter table public.job_applications enable row level security;

revoke all on table public.job_applications from anon;
grant select, insert, update, delete on table public.job_applications to authenticated;

drop policy if exists "Users can view their own applications" on public.job_applications;
create policy "Users can view their own applications"
  on public.job_applications
  for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Users can insert their own applications" on public.job_applications;
create policy "Users can insert their own applications"
  on public.job_applications
  for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own applications" on public.job_applications;
create policy "Users can update their own applications"
  on public.job_applications
  for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own applications" on public.job_applications;
create policy "Users can delete their own applications"
  on public.job_applications
  for delete
  to authenticated
  using (auth.uid() = user_id);
