create or replace function public.set_job_application_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_job_application_updated_at on public.job_applications;

create trigger set_job_application_updated_at
before update on public.job_applications
for each row
execute function public.set_job_application_updated_at();
