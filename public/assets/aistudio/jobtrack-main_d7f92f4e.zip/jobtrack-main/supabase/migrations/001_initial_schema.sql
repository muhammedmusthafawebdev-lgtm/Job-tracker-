create extension if not exists pgcrypto;

create table if not exists public.job_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  company_name text not null,
  job_title text not null,
  applied_date date not null default current_date,
  applied_time time,
  status text not null default 'Applied',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint job_applications_company_name_length check (char_length(btrim(company_name)) between 1 and 120),
  constraint job_applications_job_title_length check (char_length(btrim(job_title)) between 1 and 140),
  constraint job_applications_status_check check (status in ('Applied', 'Under Review', 'Interview', 'Offer', 'Rejected'))
);

create index if not exists job_applications_user_id_idx
  on public.job_applications (user_id);

create index if not exists job_applications_user_date_idx
  on public.job_applications (user_id, applied_date desc, applied_time desc nulls last);
