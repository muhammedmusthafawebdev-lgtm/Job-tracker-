import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import { createRoot } from 'react-dom/client'
import type { Session } from '@supabase/supabase-js'
import { getAuthRedirectUrl, supabase, supabaseConfigured } from './lib/supabase'
import './styles.css'

type ModalMode = 'new' | 'edit'
type AuthMode = 'login' | 'signup' | 'forgot'
type AuthScreen = AuthMode | 'reset'

type Application = {
  id: string
  company: string
  title: string
  appliedDate: string
  appliedTime: string
  status: string
}

type ApplicationDraft = Omit<Application, 'id' | 'status'>
type ApplicationRow = {
  id: string
  user_id: string
  company_name: string
  job_title: string
  applied_date: string
  applied_time: string | null
  status: string
}

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true }
  switch (name) {
    case 'plus': return <svg {...common}><path d="M12 5v14M5 12h14" /></svg>
    case 'calendar': return <svg {...common}><rect x="3.5" y="4.5" width="17" height="16" rx="2.5" /><path d="M7.5 2.8v3.4M16.5 2.8v3.4M3.5 9h17" /></svg>
    case 'clock': return <svg {...common}><circle cx="12" cy="12" r="8.5" /><path d="M12 7v5l3.2 2" /></svg>
    case 'briefcase': return <svg {...common}><rect x="3.5" y="6.5" width="17" height="13" rx="2.5" /><path d="M8.5 6.5V5.2A1.7 1.7 0 0 1 10.2 3.5h3.6a1.7 1.7 0 0 1 1.7 1.7v1.3M3.5 11.5h17M10 14h4" /></svg>
    case 'edit': return <svg {...common}><path d="M4.5 19.5h4l10-10a2.1 2.1 0 0 0-3-3l-10 10v3Z" /><path d="m13.8 7.2 3 3" /></svg>
    case 'trash': return <svg {...common}><path d="M4.5 7h15M9 7V4.5h6V7M7 7l.7 12.2h8.6L17 7M10 10.5v5.5M14 10.5v5.5" /></svg>
    case 'chevron': return <svg {...common}><path d="m9 18 6-6-6-6" /></svg>
    case 'arrow': return <svg {...common}><path d="M5 12h13M13 6l6 6-6 6" /></svg>
    case 'logout': return <svg {...common}><path d="M14 8V5.5A1.5 1.5 0 0 0 12.5 4h-6A1.5 1.5 0 0 0 5 5.5v13A1.5 1.5 0 0 0 6.5 20h6a1.5 1.5 0 0 0 1.5-1.5V16M10 12h9M16 8l4 4-4 4" /></svg>
    case 'close': return <svg {...common}><path d="m6 6 12 12M18 6 6 18" /></svg>
    case 'check': return <svg {...common}><path d="m5 12 4.5 4.5L19 7" /></svg>
    default: return <svg {...common}><circle cx="12" cy="12" r="8" /></svg>
  }
}

function formatDateInput(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

function localDate(dateString: string) {
  const [year, month, day] = dateString.split('-').map(Number)
  return new Date(year, month - 1, day, 12)
}

function monthLabel(dateString: string) {
  return localDate(dateString).toLocaleDateString(undefined, { month: 'long', year: 'numeric' })
}

function shortDateLabel(dateString: string) {
  return localDate(dateString).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
}

function timeLabel(time: string) {
  if (!time) return ''
  const [hours, minutes] = time.split(':').map(Number)
  return new Date(1970, 0, 1, hours, minutes).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
}

function greeting(date: Date) {
  if (date.getHours() < 12) return 'Good morning'
  if (date.getHours() < 18) return 'Good afternoon'
  return 'Good evening'
}

function isValidDateString(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false
  const date = localDate(value)
  const [year, month, day] = value.split('-').map(Number)
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day
}

function isValidTimeString(value: unknown): value is string {
  return value === '' || (typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value))
}

function normalizeTime(value: string | null) {
  return value ? value.slice(0, 5) : ''
}

function mapApplication(row: ApplicationRow): Application {
  return { id: row.id, company: row.company_name, title: row.job_title, appliedDate: row.applied_date, appliedTime: normalizeTime(row.applied_time), status: row.status }
}

function friendlyError(message: string) {
  if (/invalid login credentials/i.test(message)) return 'That email or password is not correct.'
  if (/email not confirmed/i.test(message)) return 'Check your email to confirm your account before signing in.'
  if (/rate limit|too many requests/i.test(message)) return 'Too many attempts. Please wait a moment and try again.'
  if (/network|fetch/i.test(message)) return 'We could not reach JobTrack. Check your connection and try again.'
  return 'Something went wrong. Please try again.'
}

function App() {
  const [session, setSession] = useState<Session | null>(null)
  const [authReady, setAuthReady] = useState(false)
  const [authScreen, setAuthScreen] = useState<AuthScreen>('login')
  const [applications, setApplications] = useState<Application[]>([])
  const [applicationsLoading, setApplicationsLoading] = useState(false)
  const [applicationsError, setApplicationsError] = useState('')
  const [now, setNow] = useState(() => new Date())
  const [profileOpen, setProfileOpen] = useState(false)
  const profileRef = useRef<HTMLDivElement>(null)
  const [modalMode, setModalMode] = useState<ModalMode | null>(null)
  const [editingApplication, setEditingApplication] = useState<Application | null>(null)
  const [toast, setToast] = useState('')

  useEffect(() => {
    if (!supabase) {
      setAuthReady(true)
      return
    }
    let mounted = true
    supabase.auth.getSession().then(({ data, error }) => {
      if (!mounted) return
      if (error) setApplicationsError(friendlyError(error.message))
      setSession(data.session)
      setAuthReady(true)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, nextSession) => {
      setSession(nextSession)
      setAuthReady(true)
      if (event === 'PASSWORD_RECOVERY') setAuthScreen('reset')
    })
    return () => {
      mounted = false
      subscription.unsubscribe()
    }
  }, [])

  useEffect(() => {
    const interval = window.setInterval(() => setNow(new Date()), 30_000)
    return () => window.clearInterval(interval)
  }, [])

  useEffect(() => {
    if (!profileOpen) return
    function closeOnEscape(event: KeyboardEvent) { if (event.key === 'Escape') setProfileOpen(false) }
    function closeOnOutsideClick(event: MouseEvent) { if (profileRef.current && !profileRef.current.contains(event.target as Node)) setProfileOpen(false) }
    document.addEventListener('keydown', closeOnEscape)
    document.addEventListener('mousedown', closeOnOutsideClick)
    return () => {
      document.removeEventListener('keydown', closeOnEscape)
      document.removeEventListener('mousedown', closeOnOutsideClick)
    }
  }, [profileOpen])

  useEffect(() => {
    if (!session || !supabase) {
      setApplications([])
      return
    }
    let cancelled = false
    setApplicationsLoading(true)
    setApplicationsError('')
    supabase.from('job_applications').select('id,user_id,company_name,job_title,applied_date,applied_time,status').eq('user_id', session.user.id).order('applied_date', { ascending: false }).order('applied_time', { ascending: false, nullsFirst: false }).then(({ data, error }) => {
      if (cancelled) return
      if (error) {
        setApplicationsError(friendlyError(error.message))
        setApplications([])
      } else {
        setApplications((data as ApplicationRow[]).map(mapApplication))
      }
      setApplicationsLoading(false)
    })
    return () => { cancelled = true }
  }, [session])

  useEffect(() => {
    if (!toast) return
    const timeout = window.setTimeout(() => setToast(''), 2800)
    return () => window.clearTimeout(timeout)
  }, [toast])

  async function saveApplication(draft: ApplicationDraft) {
    if (!supabase || !session) throw new Error('Your session has expired. Please sign in again.')
    const values = { company_name: draft.company.trim(), job_title: draft.title.trim(), applied_date: draft.appliedDate, applied_time: draft.appliedTime || null }
    if (editingApplication) {
      const { data, error } = await supabase.from('job_applications').update(values).eq('id', editingApplication.id).eq('user_id', session.user.id).select('id,user_id,company_name,job_title,applied_date,applied_time,status').single()
      if (error) throw error
      setApplications((current) => current.map((item) => item.id === editingApplication.id ? mapApplication(data as ApplicationRow) : item))
      setToast('Application updated')
    } else {
      const { data, error } = await supabase.from('job_applications').insert({ ...values, user_id: session.user.id }).select('id,user_id,company_name,job_title,applied_date,applied_time,status').single()
      if (error) throw error
      setApplications((current) => [mapApplication(data as ApplicationRow), ...current])
      setToast('Application added')
    }
    closeModal()
  }

  async function deleteApplication(application: Application) {
    if (!supabase || !session || !window.confirm(`Delete the ${application.title} application at ${application.company}?`)) return
    const { error } = await supabase.from('job_applications').delete().eq('id', application.id).eq('user_id', session.user.id)
    if (error) { setApplicationsError(friendlyError(error.message)); return }
    setApplications((current) => current.filter((item) => item.id !== application.id))
    setToast('Application deleted')
  }

  async function handleLogout() {
    if (!supabase) return
    const { error } = await supabase.auth.signOut()
    if (error) setApplicationsError(friendlyError(error.message))
    setProfileOpen(false)
  }

  function openNewApplication() { setEditingApplication(null); setModalMode('new') }
  function openEditApplication(application: Application) { setEditingApplication(application); setModalMode('edit') }
  function closeModal() { setModalMode(null); setEditingApplication(null) }

  if (!authReady) return <LoadingScreen />
  if (authScreen === 'reset') return <ResetPasswordPanel onComplete={() => setAuthScreen('login')} />
  if (!session) return <AuthPanel mode={authScreen} onModeChange={setAuthScreen} />

  const name = session.user.email?.split('@')[0].replace(/[._-]+/g, ' ').split(' ')[0] || 'there'
  const thisMonth = applications.filter((application) => { const date = localDate(application.appliedDate); return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear() }).length

  return (
    <div className="app-shell">
      <header className="topbar"><div className="topbar-inner">
        <button className="brand" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="Back to top"><span className="brand-mark">J</span><span className="brand-name">JobTrack</span></button>
        <div className="topbar-actions"><div className="profile-wrap" ref={profileRef}>
          <button className="profile-button" onClick={() => setProfileOpen((open) => !open)} aria-expanded={profileOpen} aria-controls="profile-menu"><span className="avatar">{name.slice(0, 1).toUpperCase()}</span><span className="profile-label">{name}</span><span className="profile-chevron"><Icon name="chevron" size={14} /></span></button>
          {profileOpen && <div className="profile-menu" id="profile-menu" role="menu"><div className="profile-menu-email">{session.user.email}</div><button role="menuitem" onClick={handleLogout}><Icon name="logout" size={16} /> Log out</button></div>}
        </div></div>
      </div></header>

      <main className="main-content">
        <section className="hero-row"><div><p className="eyebrow">{greeting(now)}</p><h1>Keep moving forward<span className="period">.</span></h1><p className="hero-note">A clear view of every opportunity you’re pursuing.</p></div><button className="primary-button hero-add" onClick={openNewApplication}><Icon name="plus" size={17} /> Add application</button></section>
        <section className="date-strip" aria-label="Current date and time"><div className="date-main"><span className="live-dot" /><strong>{now.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}</strong><span className="date-separator">/</span><span>{now.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</span></div><span className="date-year">{now.getFullYear()}</span></section>
        <section className="stats-grid" aria-label="Application statistics"><Stat label="Applications" value={applications.length.toString()} /><Stat label="This month" value={thisMonth.toString()} /><Stat label="Days tracked" value={new Set(applications.map((application) => application.appliedDate)).size.toString()} /><Stat label="Times added" value={applications.filter((application) => application.appliedTime).length.toString()} /></section>
        <section className="applications-section"><div className="section-heading"><div><p className="eyebrow">Your activity</p><h2>Application timeline</h2></div><button className="text-button" onClick={openNewApplication}><span>New application</span> <Icon name="arrow" size={16} /></button></div>
          {applicationsError && <div className="form-error" role="alert">{applicationsError}</div>}
          {applicationsLoading ? <div className="loading-state" aria-live="polite">Loading applications…</div> : applications.length === 0 ? <EmptyState onAdd={openNewApplication} /> : <ApplicationTimeline applications={applications} onEdit={openEditApplication} onDelete={deleteApplication} />}
        </section>
      </main>
      <footer className="footer"><span>JobTrack</span><span>Private by default</span></footer>
      {modalMode && <ApplicationModal mode={modalMode} application={editingApplication} onClose={closeModal} onSave={saveApplication} />}
      {toast && <div className="toast"><span className="toast-check"><Icon name="check" size={15} /></span>{toast}</div>}
    </div>
  )
}

function LoadingScreen() { return <div className="loading-screen" role="status">Loading JobTrack…</div> }
function Stat({ label, value }: { label: string; value: string }) { return <div className="stat"><span>{label}</span><strong>{value}</strong></div> }

function AuthPanel({ mode, onModeChange }: { mode: AuthMode; onModeChange: (mode: AuthMode) => void }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  const busyRef = useRef(false)

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (busyRef.current) return
    setError(''); setNotice('')
    const normalizedEmail = email.trim().toLowerCase()
    if (!supabase || !supabaseConfigured) { setError('Add the Supabase publishable key to the local environment before signing in.'); return }
    if (!/^\S+@\S+\.\S+$/.test(normalizedEmail) || normalizedEmail.length > 254) { setError('Enter a valid email address.'); return }
    if (mode !== 'forgot' && (password.length < 8 || password.length > 128)) { setError('Use at least 8 characters for your password.'); return }
    busyRef.current = true
    setBusy(true)
    try {
      if (mode === 'forgot') {
        const { error: resetError } = await supabase.auth.resetPasswordForEmail(normalizedEmail, { redirectTo: getAuthRedirectUrl() })
        if (resetError) throw resetError
        setNotice('If an account exists for that email, a reset link is on its way.')
      } else if (mode === 'signup') {
        const { data, error: signupError } = await supabase.auth.signUp({ email: normalizedEmail, password, options: { emailRedirectTo: getAuthRedirectUrl() } })
        if (signupError && /already registered/i.test(signupError.message)) {
          setNotice('If an account exists for that email, check your inbox or sign in.')
        } else if (signupError) {
          throw signupError
        } else {
          setNotice(data.session ? 'Your account is ready.' : 'Check your email to verify your account, then sign in.')
        }
      } else {
        const { error: loginError } = await supabase.auth.signInWithPassword({ email: normalizedEmail, password })
        if (loginError) throw loginError
      }
    } catch (caught) { setError(friendlyError(caught instanceof Error ? caught.message : 'Something went wrong. Please try again.')) }
    finally { busyRef.current = false; setBusy(false) }
  }

  const isForgot = mode === 'forgot'
  return <div className="auth-shell"><div className="auth-intro"><button className="brand auth-brand" type="button" onClick={() => onModeChange('login')}><span className="brand-mark">J</span><span className="brand-name">JobTrack</span></button><div className="auth-statement"><p className="eyebrow">Your next move, clearly.</p><h1>Make space for the work that matters<span className="period">.</span></h1><p>Keep every application in view, without adding more noise to your day.</p></div><div className="auth-footer-note">A simple place to keep moving.</div></div><div className="auth-form-wrap"><div className="auth-form-header"><p className="eyebrow">{isForgot ? 'Account recovery' : mode === 'login' ? 'Welcome back' : 'Create your space'}</p><h2>{isForgot ? 'Reset your password' : mode === 'login' ? 'Sign in to JobTrack' : 'Start tracking'}</h2><p>{isForgot ? 'We’ll send a secure recovery link.' : mode === 'login' ? 'Pick up where you left off.' : 'A clear record for every opportunity.'}</p></div><form className="auth-form" onSubmit={submit}><label htmlFor="auth-email">Email address<input id="auth-email" type="email" autoComplete="email" required maxLength={254} value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" /></label>{!isForgot && <label htmlFor="auth-password">Password<span className="password-field"><input id="auth-password" type={showPassword ? 'text' : 'password'} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required minLength={8} maxLength={128} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 8 characters" /><button type="button" className="password-toggle" onClick={() => setShowPassword((visible) => !visible)}>{showPassword ? 'Hide' : 'Show'}</button></span></label>}{error && <p className="form-error" role="alert">{error}</p>}{notice && <p className="form-success" role="status">{notice}</p>}<button className="primary-button auth-submit" type="submit" disabled={busy}>{busy ? 'Please wait…' : isForgot ? 'Send reset link' : mode === 'login' ? 'Continue' : 'Create account'} {!busy && <Icon name="arrow" size={16} />}</button></form><div className="auth-switch">{mode === 'login' && <><span>Forgot your password?</span><button type="button" onClick={() => { onModeChange('forgot'); setError(''); setNotice('') }}>Reset it</button></>}{mode === 'forgot' && <><span>Remember your password?</span><button type="button" onClick={() => { onModeChange('login'); setError(''); setNotice('') }}>Sign in</button></>}{mode === 'signup' && <><span>Already have an account?</span><button type="button" onClick={() => { onModeChange('login'); setError(''); setNotice('') }}>Sign in</button></>}{mode === 'login' && <span className="auth-switch-secondary"><span>New to JobTrack?</span><button type="button" onClick={() => { onModeChange('signup'); setError(''); setNotice('') }}>Create an account</button></span>}</div><p className="local-note">Secure sign-in · your data is stored in Supabase.</p></div></div>
}

function ResetPasswordPanel({ onComplete }: { onComplete: () => void }) {
  const [password, setPassword] = useState('')
  const [confirmation, setConfirmation] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  const busyRef = useRef(false)
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (busyRef.current) return; setError(''); setNotice('')
    if (!supabase) { setError('This recovery session is unavailable. Request a new reset link.'); return }
    if (password.length < 8 || password.length > 128 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) { setError('Use 8+ characters with uppercase, lowercase, and a number.'); return }
    if (password !== confirmation) { setError('Passwords do not match.'); return }
    busyRef.current = true
    setBusy(true)
    try {
      const { error: updateError } = await supabase.auth.updateUser({ password })
      if (updateError) throw updateError
      setNotice('Your password was updated. You can sign in now.')
      await supabase.auth.signOut()
      window.setTimeout(onComplete, 900)
    } catch (caught) { setError(friendlyError(caught instanceof Error ? caught.message : 'This recovery link is no longer valid.')) }
    finally { busyRef.current = false; setBusy(false) }
  }
  return <div className="auth-shell"><div className="auth-intro"><div className="brand auth-brand"><span className="brand-mark">J</span><span className="brand-name">JobTrack</span></div><div className="auth-statement"><p className="eyebrow">Account recovery</p><h1>Make space for the work that matters<span className="period">.</span></h1><p>Choose a new password to return to your applications.</p></div></div><div className="auth-form-wrap"><div className="auth-form-header"><p className="eyebrow">Secure reset</p><h2>Choose a new password</h2><p>Use a password you have not used before.</p></div><form className="auth-form" onSubmit={submit}><label htmlFor="reset-password">New password<span className="password-field"><input id="reset-password" type={showPassword ? 'text' : 'password'} required minLength={8} maxLength={128} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="8+ characters, upper/lowercase, number" /><button type="button" className="password-toggle" onClick={() => setShowPassword((visible) => !visible)}>{showPassword ? 'Hide' : 'Show'}</button></span></label><label htmlFor="reset-confirmation">Confirm password<input id="reset-confirmation" type={showPassword ? 'text' : 'password'} required value={confirmation} onChange={(event) => setConfirmation(event.target.value)} placeholder="Repeat your password" /></label>{error && <p className="form-error" role="alert">{error}</p>}{notice && <p className="form-success" role="status">{notice}</p>}<button className="primary-button auth-submit" type="submit" disabled={busy}>{busy ? 'Please wait…' : 'Update password'} {!busy && <Icon name="arrow" size={16} />}</button></form></div></div>
}

function EmptyState({ onAdd }: { onAdd: () => void }) { return <div className="empty-state"><div className="empty-line" /><div className="empty-copy"><span className="empty-icon"><Icon name="briefcase" size={22} /></span><div><h3>Nothing here yet</h3><p>Start with the opportunity you’re thinking about.</p></div></div><button className="secondary-button" onClick={onAdd}><Icon name="plus" size={16} /> Add your first application</button></div> }

function ApplicationTimeline({ applications, onEdit, onDelete }: { applications: Application[]; onEdit: (application: Application) => void; onDelete: (application: Application) => void | Promise<void> }) {
  const grouped = useMemo(() => { const sorted = [...applications].sort((a, b) => `${b.appliedDate}${b.appliedTime}`.localeCompare(`${a.appliedDate}${a.appliedTime}`)); const groups = new Map<string, Application[]>(); sorted.forEach((application) => { const key = application.appliedDate.slice(0, 7); groups.set(key, [...(groups.get(key) ?? []), application]) }); return [...groups.entries()] }, [applications])
  return <div className="timeline">{grouped.map(([month, items]) => <div className="month-group" key={month}><div className="month-label">{monthLabel(`${month}-01`)}</div><div className="timeline-items">{items.map((application) => <article className="application-row" key={application.id}><div className="application-date"><strong>{localDate(application.appliedDate).getDate()}</strong><span>{localDate(application.appliedDate).toLocaleDateString(undefined, { weekday: 'short' })}</span></div><div className="application-marker" /><div className="application-content"><div className="application-main"><div><h3>{application.title}</h3><p>{application.company}</p></div><div className="application-meta">{application.appliedTime && <span><Icon name="clock" size={14} /> {timeLabel(application.appliedTime)}</span>}<span className="applied-label">{application.status}</span></div></div><div className="application-actions"><span>{shortDateLabel(application.appliedDate)}</span><button className="row-action" onClick={() => onEdit(application)} aria-label={`Edit ${application.title}`}><Icon name="edit" size={15} /></button><button className="row-action danger" onClick={() => onDelete(application)} aria-label={`Delete ${application.title}`}><Icon name="trash" size={15} /></button></div></div></article>)}</div></div>)}</div>
}

function ApplicationModal({ mode, application, onClose, onSave }: { mode: ModalMode; application: Application | null; onClose: () => void; onSave: (draft: ApplicationDraft) => Promise<void> }) {
  const [company, setCompany] = useState(application?.company ?? '')
  const [title, setTitle] = useState(application?.title ?? '')
  const [appliedDate, setAppliedDate] = useState(application?.appliedDate ?? formatDateInput(new Date()))
  const [appliedTime, setAppliedTime] = useState(application?.appliedTime ?? '')
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  const savingRef = useRef(false)
  const dialogRef = useRef<HTMLDivElement>(null)
  const firstFieldRef = useRef<HTMLInputElement>(null)
  useEffect(() => { firstFieldRef.current?.focus(); function handleKeyDown(event: KeyboardEvent) { if (event.key === 'Escape') onClose(); if (event.key !== 'Tab' || !dialogRef.current) return; const focusable = [...dialogRef.current.querySelectorAll<HTMLElement>('button, input')].filter((element) => !element.hasAttribute('disabled')); const first = focusable[0]; const last = focusable[focusable.length - 1]; if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus() } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus() } } document.addEventListener('keydown', handleKeyDown); return () => document.removeEventListener('keydown', handleKeyDown) }, [onClose])
  async function submit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); if (savingRef.current) return; setError(''); if (!company.trim() || company.trim().length > 120 || !title.trim() || title.trim().length > 140) { setError('Enter a company name and job title within the character limits.'); return } if (!isValidDateString(appliedDate)) { setError('Choose a valid application date.'); return } if (!isValidTimeString(appliedTime)) { setError('Choose a valid application time or leave it blank.'); return } savingRef.current = true; setSaving(true); try { await onSave({ company: company.trim(), title: title.trim(), appliedDate, appliedTime }) } catch (caught) { setError(friendlyError(caught instanceof Error ? caught.message : 'The application could not be saved.')) } finally { savingRef.current = false; setSaving(false) } }
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !saving) onClose() }}><div className="modal" ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="application-modal-title"><div className="modal-header"><div><p className="eyebrow">{mode === 'new' ? 'New entry' : 'Edit entry'}</p><h2 id="application-modal-title">{mode === 'new' ? 'Add application' : 'Update application'}</h2></div><button type="button" className="icon-button" onClick={onClose} disabled={saving} aria-label="Close dialog"><Icon name="close" /></button></div><form className="application-form" onSubmit={submit}><div className="form-grid"><label className="span-2" htmlFor="application-company">Company name<input id="application-company" ref={firstFieldRef} required maxLength={120} value={company} onChange={(event) => setCompany(event.target.value)} placeholder="e.g. Arc" /></label><label className="span-2" htmlFor="application-title">Job title<input id="application-title" required maxLength={140} value={title} onChange={(event) => setTitle(event.target.value)} placeholder="e.g. Product designer" /></label><label htmlFor="application-date">Application date<input id="application-date" type="date" required value={appliedDate} onChange={(event) => setAppliedDate(event.target.value)} /></label><label htmlFor="application-time">Application time <span className="optional">Optional</span><input id="application-time" type="time" value={appliedTime} onChange={(event) => setAppliedTime(event.target.value)} /></label></div>{appliedDate && <p className="derived-date"><Icon name="calendar" size={15} /> This will appear under <strong>{monthLabel(appliedDate)}</strong>.</p>}{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose} disabled={saving}>Cancel</button><button type="submit" className="primary-button" disabled={saving}>{saving ? 'Saving…' : mode === 'new' ? 'Save application' : 'Save changes'} {!saving && <Icon name="arrow" size={16} />}</button></div></form></div></div>
}

export default App

createRoot(document.getElementById('root')!).render(<App />)
