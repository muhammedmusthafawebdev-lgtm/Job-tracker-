export default {
  logoUrl: "https://dummyimage.com/64x64/111111/ffffff.png&text=J"
}
